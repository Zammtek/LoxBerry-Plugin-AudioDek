#!/bin/bash
mkdir -p /opt/loxberry/config/plugins/audiodek /opt/loxberry/data/plugins/audiodek/backups
chmod 755 /opt/loxberry/webfrontend/htmlauth/plugins/audiodek/index.cgi 2>/dev/null || true
chmod 755 /opt/loxberry/bin/plugins/audiodek/dashboard.py 2>/dev/null || true
exit 0
